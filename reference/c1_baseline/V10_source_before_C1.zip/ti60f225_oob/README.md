# Ti60F225 赛题四 — V10 手动阈值与暗部调试

完整 Efinity 工程入口是 `ti60f225_oob.xml`。V10 保留 V9 的连续 HDMI 时序和 DDR 改进，增加实用阈值上下限、步进1、长按连调、常驻模式/十进制阈值提示。操作说明见 `docs/V10_THRESHOLD_TUNING.md`，实际验证见 `reports/V10_VALIDATION.md`。原 V9 工程与烧录文件保留在上一级的独立目录，未覆盖。

## Calibrated preset (from measured V7 white-card test)

- Uncorrected sample: RGB = `F4 / 6A / C4` (decimal 244 / 106 / 196).
- New gain preset in Q8 format (0x100=1.0): `R=0C0`, `G=1C0`, `B=0F0`.
- Predicted output sample at the same exposure and illumination: `B7 / B9 / B7` (183 / 185 / 183).
- This is a **scene-specific software RGB gain preset**, not sensor AWB register calibration; further white-card tests are recommended.

## HDMI modes and buttons

- **上电模式3**：左原图/右最终二值边缘，保留小型参数条。
- **模式0/1**：彩色/灰度原图；阈值不改变这两个页面的图像。
- **模式2**：最终二值 Sobel；**模式5**：梯度幅值预览，没有经过二值阈值筛选，调阈值不改变模式5的梯度画面。
- **模式0～5参数条**：`V10 M:2 T:024 MAX:128 S:1`。T 是十进制，到顶显示黄色 MAX，到底显示 MIN。黑色边缘背景不影响参数条。
- **模式6**：完整白平衡、帧率及 U/D/R/L/O 诊断；T 同样改为十进制，其他 RGB/GAIN 值仍为十六进制。
- KEY3 short press cycles modes 0 to 6, so from boot mode 3 press KEY3 **three times** to reach mode 6. KEY3 long press in mode 6 selects `SEL:R/G/B`; KEY1 increases and KEY2 decreases the selected gain in 1/16 steps (minimum 0.5, maximum 2.25). Outside mode 6 KEY1/2 continue adjusting the Sobel threshold.

上电模式3，KEY3 短按顺序为 `3→4→5→6→0→1→2→3`。除模式6外，KEY1 增阈值、KEY2 减阈值，**范围4～128，默认24，步进1**。长按约0.5秒后每0.1秒调整1。到上下限后保持数值，不回绕；host 写入也经过同样的限制；下一帧生效。模式6的 KEY1/2 仍调白平衡增益。

其他页面长按 KEY3 依次切换旁路、中值、高斯和细节增强。KEY1+KEY2 同按冻结；KEY0 整板复位。RGB 增益仍作用于全部模式。

暗部弱边缘先用 KEY2 从24逐步降至20、16、12观察；KEY1 增大会减少边缘。128是手动调节的实用上限，不保证任何场景都检出边缘。均匀或缺乏对比的图像仍可全黑，但参数条和 HDMI 同步应保持。

## 沿用 V9 的稳定性结构

- 连续 `img_video_out` 替代原 CVO：数据不足时填黑、丢弃受损帧尾，在下一 SOF/有效帧边界恢复；数据是否可用不改变 HS/VS/DE 周期。
- DDR reader 忙时保留一项请求；writer 最多 4 个 B 响应在途，全部成功后才发布帧。三缓冲最新完整帧策略保留。
- 捕获、显示异步 FIFO 各加深到 2048 个 AXI128 word；溢出改成源端单比特锁存后同步，补齐诊断第一拍 CDC 约束。
- 摄像头 stream-on 移到配置表最后，几何/增益在停流时完成；PLL、HTS/VTS 和 MIPI 速率保持原配置。

## Frame-rate interpretation

用户 V8 实测照片为 `CAM:30 DDR:30 SCREEN:30`。这些是每 60 个 HDMI 输出帧中的摄像头帧、成功写入帧、选中的新帧数；**SCREEN 不是 HDMI 刷新率**。本版 HDMI 保持 1080p60。源端每秒提供约 30 帧时，会重复完整帧。DDR 优化改善吞吐和抗抖动；要真正将摄像头提高到 60 fps，还需要与当前 SC431HAI 模组匹配、经过实板验证的 1080p60 寄存器表。

## Build

Open `ti60f225_oob.xml` in Efinity and run synthesis, Interface Designer, place/route, timing analysis and bitstream generation. CLI: `efx_run ti60f225_oob.xml --flow compile`. Efinity's `full` flow also invokes unconfigured project-level IP simulation; use `compile` for the complete programming-file build.

本版烧录文件为 `programming/ti60f225_oob_V10.bit`，SHA256 在 `reports/v10_release_manifest.json`。烧入后参数条应显示 V10、MAX:128、S:1。更改 RTL 后必须重新编译。

## Validation status

Run `python scripts/run_tests.py` for the full regression; set `IVERILOG`/`VVP` for Icarus, or `RTL_SIM=modelsim` and `MODELSIM_BIN` for a licensed ModelSim/Questa. Appending testbench names runs just those tests. Actual results are recorded in `reports/V10_VALIDATION.md`. Software tests do not replace board-level HDMI/DDR/camera acceptance.

See [`docs/V8_WB_CALIBRATION.md`](docs/V8_WB_CALIBRATION.md) for details.
